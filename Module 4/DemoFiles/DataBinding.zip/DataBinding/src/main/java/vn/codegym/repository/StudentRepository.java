package vn.codegym.repository;

public interface StudentRepository extends Repository {
}
